#!/bin/bash

if [ ! -d "/usr/local/nagios/etc" ]; then
        yum clean all && yum update all
        yum install wget glibc-devel xinetd openssl-devel -y
        yum groupinstall 'Development Tools' -y

        if [ `cat /etc/passwd | grep ec2-user | cut -d: -f1| awk '{print $0}' | sed 's/ //g'` ]; then
                echo "This user is already  exist"
        else
                useradd nagios
        fi

        # No need to download the file. Download once and copy every time destination.
        tar zxvf nrpe-2-15.tar.gz
        cd nrpe-nrpe-2-15
        ./configure --enable-command-args
        make
        make install
        make install-xinetd
        mkdir /usr/local/nagios/etc
        cp ../nrpe2.cfg /usr/local/nagios/etc/nrpe.cfg
        cp ../nrpe_sample /etc/xinetd.d/nrpe
        echo "nrpe 5666/tcp" >> /etc/services
        cd ../
        tar zxvf nagios-plugins-2.0.3.tar.gz
        cd nagios-plugins-2.0.3
        ./configure --with-nagios-user=nagios --with-nagios-group=nagios
        make
        make install
        service xinetd restart
else
        echo "This path /usr/local/nagios/etc already exist"
fi


